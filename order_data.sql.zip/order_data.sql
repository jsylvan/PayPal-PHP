-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 04, 2013 at 05:43 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `payment`
--

-- --------------------------------------------------------

--
-- Table structure for table `order_data`
--

CREATE TABLE `order_data` (
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `order_id` int(11) NOT NULL auto_increment,
  `email` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `currency` varchar(200) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `trans_type` varchar(200) NOT NULL,
  `response` text NOT NULL,
  `order_time` varchar(200) NOT NULL,
  PRIMARY KEY  (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `order_data`
--

INSERT INTO `order_data` (`first_name`, `last_name`, `order_id`, `email`, `status`, `amount`, `currency`, `transaction_id`, `trans_type`, `response`, `order_time`) VALUES
('iPhone', 'Developer', 1, 'iphonedeveloper9@gmail.com', 'Completed', '250.00', 'USD', '7R130791VP317623P', 'expresscheckout', '{"RECEIVEREMAIL":"anil1%40sapovadiya%2ecom","RECEIVERID":"3Z46NFJQ5Z7WJ","EMAIL":"iphonedeveloper9%40gmail%2ecom","PAYERID":"BFJFA8AFFLG9U","PAYERSTATUS":"unverified","COUNTRYCODE":"IN","SHIPTONAME":"iPhone%20Developer","SHIPTOSTREET":"lakshminagar%2c%20varachha%2c%20surat","SHIPTOCITY":"surat","SHIPTOSTATE":"Gujarat","SHIPTOCOUNTRYCODE":"IN","SHIPTOCOUNTRYNAME":"India","SHIPTOZIP":"395010","ADDRESSOWNER":"PayPal","ADDRESSSTATUS":"Unconfirmed","SALESTAX":"0%2e00","SHIPAMOUNT":"0%2e00","SHIPHANDLEAMOUNT":"0%2e00","TIMESTAMP":"2013%2d09%2d04T17%3a41%3a46Z","CORRELATIONID":"522dfacd7926d","ACK":"Success","VERSION":"76%2e0","BUILD":"7507921","FIRSTNAME":"iPhone","LASTNAME":"Developer","TRANSACTIONID":"7R130791VP317623P","TRANSACTIONTYPE":"expresscheckout","PAYMENTTYPE":"instant","ORDERTIME":"2013%2d09%2d04T17%3a41%3a40Z","AMT":"250%2e00","FEEAMT":"10%2e05","TAXAMT":"0%2e00","CURRENCYCODE":"USD","PAYMENTSTATUS":"Completed","PENDINGREASON":"None","REASONCODE":"None","PROTECTIONELIGIBILITY":"PartiallyEligible","PROTECTIONELIGIBILITYTYPE":"ItemNotReceivedEligible","L_QTY0":"1","L_TAXAMT0":"0%2e00","L_CURRENCYCODE0":"USD"}', '2013-09-04T17:41:40Z');
